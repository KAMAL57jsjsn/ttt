<?php
function hotmail($email){
$ch = curl_init();
curl_setopt_array($ch,array(
CURLOPT_POST => 1,
CURLOPT_URL => 'https://login.live.com/GetCredentialType.srf?opid=C1DA5AFB2C9B3F2D&id=292841&wa=wsignin1.0&rpsnv=13&ct=1642601634&rver=7.0.6737.0&wp=MBI_SSL&wreply=https%3a%2f%2foutlook.live.com%2fowa%2f%3fnlp%3d1%26RpsCsrfState%3d90e49d22-757d-c728-0abb-2ad43c95c035&id=292841&aadredir=1&CBCXT=out&lw=1&fl=dob%2cflname%2cwld&pcexp=false&cobrandid=90015&mkt=AR-AE&lc=14337&uaid=e479c5486ade47bfa45e59483ba839e4',
CURLOPT_RETURNTRANSFER => true,
CURLOPT_HTTPHEADER => array('Connection: keep-alive',
'sec-ch-ua: " Not A;Brand";v="99", "Chromium";v="96"',
'sec-ch-ua-mobile: ?1',
'User-Agent: Mozilla/5.0 (Linux; Android 11; SM-A217F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.46 Mobile Safari/537.36',
'client-request-id: e479c5486ade47bfa45e59483ba839e4',
'Content-type: application/json; charset=UTF-8',
'hpgid: 38',
'Accept: application/json',
'hpgact: 0',
'sec-ch-ua-platform: "Android"',
'Origin: https://login.live.com',
'Sec-Fetch-Site: same-origin',
'Sec-Fetch-Mode: cors',
'Sec-Fetch-Dest: empty',
'Referer: https://login.live.com/login.srf?wa=wsignin1.0&rpsnv=13&ct=1642601634&rver=7.0.6737.0&wp=MBI_SSL&wreply=https%3a%2f%2foutlook.live.com%2fowa%2f%3fnlp%3d1%26RpsCsrfState%3d90e49d22-757d-c728-0abb-2ad43c95c035&id=292841&aadredir=1&CBCXT=out&lw=1&fl=dob%2cflname%2cwld&pcexp=false&cobrandid=90015',
'Accept-Language: ar-AE,ar;q=0.9,en-US;q=0.8,en;q=0.7,de-DE;q=0.6,de;q=0.5',
'Cookie: logonLatency=LGN01=637781984347016043; uaid=e479c5486ade47bfa45e59483ba839e4; MSPRequ=id=292841&lt=1642601635&co=1; MSCC=196.132.49.148-EG; OParams=11O.DZPZejreGA2S*S9oZYhe0dV*xbBP17INRe1ENFpj\u0021\u0021rOS1klXccTK4BODFA8**vXynMx3chPEwWf9tmNweKF2tBaetlA2O1REG9y9i9xwQ3UecPQve*CjwRLPecCS9rnmuXFYBvg0*vV\u0021hFtI4rCeMmIB12FeK7H0kGzM*8YN8BhI6n6WyyEYHNSldwDvHf7Yto33ApOl7CZv\u0021\u0021FFFMm*vLvE\u0021*rEqs05uc\u0021utKpxm3qoRLHZVbFvgyTP7Mq5bnckdiFDzcezcidKhgYDp50hTcQ\u0021pyM2KKooE*V03MjPGC2Sprpnrww\u0021bbZYSwuaG\u0021W9EfGPpdZCChdUv\u0021ODdx6WA8HrxHFH2dSt*jUwDsTuo2mx*VR6\u0021HjDpCBJBRmcoL6SQ18lFEL5YN52DI0f9GV\u0021TX1uEJ9H6tQAoF2CGPZjGfMI\u00217V88ehjrsl\u0021kewEQ19xcYGMoO850\u0021t1D6LQOj10yBxyGbRgqpeB4FJ60t9voU*; MSPOK=$uuid-78ec565b-e8c5-41fb-9694-1b4f2f69a805'),
CURLOPT_POSTFIELDS => '{"username":"'.$email.'","uaid":"e479c5486ade47bfa45e59483ba839e4","isOtherIdpSupported":true,"checkPhones":false,"isRemoteNGCSupported":true,"isCookieBannerShown":false,"isFidoSupported":false,"forceotclogin":false,"otclogindisallowed":false,"isExternalFederationDisallowed":false,"isRemoteConnectSupported":false,"federationFlags":3,"isSignup":false,"flowToken":"DW8mIgMsVQvuQirJ8f8mhAqLompLoTgxpQ*4hpxoWt549npyID3EDPSRDhRC\u0021LGDauDSr9CS47VLFK7jALrt3RRR55GJ\u0021VP02Fhjg3b3uvqjARDXcET2cQSQlI*iorzoOwILg3PTVEagjdWVw502SekiKf5Tng0CURMFeVZ5PazyoTSSJorhS7WJINHeFnNx57ChewGSd1TJK9BZkN*jGv7A4zPhlp69CeQ7KKC56dR*LqNIwcGPMS8EFPKtRNd0zplKq78JEbQnyhZYPuq1BnA$"}',
CURLOPT_ENCODING => "gzip"
));
$result = curl_exec($ch);
$result = json_decode($result);
$valid = $result->IfExistsResult;
if($valid == '1'){
return 'true';
} else {
return 'false';
}
}
function yahoo($email){
$ch = curl_init();
curl_setopt_array($ch,array(
CURLOPT_POST => 1,
CURLOPT_URL => 'https://login.yahoo.com/?',
CURLOPT_RETURNTRANSFER => true,
CURLOPT_HTTPHEADER => array(
'Connection: keep-alive',
'sec-ch-ua: " Not A;Brand";v="99", "Chromium";v="96"',
'content-type: application/x-www-form-urlencoded; charset=UTF-8',
'X-Requested-With: XMLHttpRequest',
'sec-ch-ua-mobile: ?1',
'User-Agent: Mozilla/5.0 (Linux; Android 11; SM-A217F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.46 Mobile Safari/537.36',
'sec-ch-ua-platform: "Android"',
'Accept: */*',
'Origin: https://login.yahoo.com',
'Sec-Fetch-Site: same-origin',
'Sec-Fetch-Mode: cors',
'Sec-Fetch-Dest: empty',
'Referer: https://login.yahoo.com/?',
'Accept-Language: ar-AE,ar;q=0.9,en-US;q=0.8,en;q=0.7,de-DE;q=0.6,de;q=0.5',
'Cookie: B=e855arhgpi713&b=3&s=uu; APID=UP627f3940-4a1b-11ec-a99a-06618aa3b3b6; A1=d=AQABBCMcmWECENs6RpfkNR7Hu2a7gNyqFOQFEgEBBgCn6mHrYdxH0iMA_eMBAAcIIxyZYdyqFOQ&S=AQAAAkco8V9aDEgoBt0YFY5VhN0; A3=d=AQABBCMcmWECENs6RpfkNR7Hu2a7gNyqFOQFEgEBBgCn6mHrYdxH0iMA_eMBAAcIIxyZYdyqFOQ&S=AQAAAkco8V9aDEgoBt0YFY5VhN0; GUC=AQEBBgBh6qdh60IdcAQe; A1S=d=AQABBCMcmWECENs6RpfkNR7Hu2a7gNyqFOQFEgEBBgCn6mHrYdxH0iMA_eMBAAcIIxyZYdyqFOQ&S=AQAAAkco8V9aDEgoBt0YFY5VhN0&j=US; AS=v=1&s=oetJZjWr&d=A61ec25ac|88yp1u7.2So6V9g4ZWt0GpKEWuEqMXn.31HuIDFXEA9j327vwzyN34mTtvnlbMCGrTWu.ZWfTLGLO4MXZG6mhw8_xttJOFeiAUKijjRuLlN6yPMgyRQqAO5syDBPpp64cElX6qCsq_PRRHZRze7m.xDcDL5K8WnaGOYPqto6SIJxD.KG8t85a2V3n6JIYdx941OGFXlEzaTr9Yn4z4TJ_O8ZrOZYH2fX8dPF4kNdc.k2Bh505uLBvZ8x8a0I14UmSIqSBDCW5DYoGLN.d.Y5xYVQ3lUPfHWCoNmbozoW.vCngrfoo97lPepYbDKNxEToyZBmNEqQmd6VuGR2iwWPDew4osRl6rn_6_XExItfAkO3b0X72WOY5VPGkgvE1PniIM1VxOVhbPidzWGofYWHCMEUdj7LgswFilAHS3E1KAJpek.qmrzids15MxqYADfsZT5O5wuCvMxHQqQMkA3Z6MuPAWopI.NGnKBxsFlhjX5KVWelYPpKOzDVaQ.745YTxgtXUq9mAqUuTXF_QvIVdCtuBSivHlZnDQ1oCeVKZ5X9rljbCgCNZybkvwMVULYGfAzCT2Y81jt64R_JLqXCdrFlDgTbZxJrQhqL_oW3dXIgWWAZQjQngXUZ9GLPLExWzm2LCufZrIhuFqZ_fLGysAopwTJLdkPwOj1Oo1gvl1P3bvOmvBQ_DRY3cgoS6EFRuKOCiOwzb4TamK.r2ivCuZxigZjnbcTxy2JeRQK9BsBkqkQ3cyXHPJbEv84RgjRMmmNiPbJM.SGKVnod6Amu963xd4iitWtJMkn6G_qn3MxWlkdi~A'),
CURLOPT_POSTFIELDS => 'browser-fp-data=%7B%22language%22%3A%22ar-AE%22%2C%22colorDepth%22%3A24%2C%22deviceMemory%22%3A4%2C%22pixelRatio%22%3A1.75%2C%22hardwareConcurrency%22%3A8%2C%22timezoneOffset%22%3A-120%2C%22timezone%22%3A%22Africa%2FCairo%22%2C%22sessionStorage%22%3A1%2C%22localStorage%22%3A1%2C%22indexedDb%22%3A1%2C%22openDatabase%22%3A1%2C%22cpuClass%22%3A%22unknown%22%2C%22platform%22%3A%22Linux%20aarch64%22%2C%22doNotTrack%22%3A%22unknown%22%2C%22plugins%22%3A%7B%22count%22%3A0%2C%22hash%22%3A%2224700f9f1986800ab4fcc880530dd0ed%22%7D%2C%22canvas%22%3A%22canvas%20winding%3Ayes~canvas%22%2C%22webgl%22%3A1%2C%22webglVendorAndRenderer%22%3A%22ARM~Mali-G52%22%2C%22adBlock%22%3A0%2C%22hasLiedLanguages%22%3A0%2C%22hasLiedResolution%22%3A0%2C%22hasLiedOs%22%3A0%2C%22hasLiedBrowser%22%3A0%2C%22touchSupport%22%3A%7B%22points%22%3A5%2C%22event%22%3A1%2C%22start%22%3A1%7D%2C%22fonts%22%3A%7B%22count%22%3A11%2C%22hash%22%3A%221b3c7bec80639c771f8258bd6a3bf2c6%22%7D%2C%22audio%22%3A%22124.0434488439787%22%2C%22resolution%22%3A%7B%22w%22%3A%22412%22%2C%22h%22%3A%22915%22%7D%2C%22availableResolution%22%3A%7B%22w%22%3A%22915%22%2C%22h%22%3A%22412%22%7D%2C%22ts%22%3A%7B%22serve%22%3A1642779692759%2C%22render%22%3A1642779694863%7D%7D&crumb=y%2FsMq7ttQms&acrumb=oetJZjWr&sessionIndex=QQ--&displayName=&deviceCapability=%7B%22pa%22%3A%7B%22status%22%3Atrue%7D%7D&username='.$email.'&passwd=&signin=%D8%A7%D9%84%D8%AA%D8%A7%D9%84%D9%8A',
CURLOPT_ENCODING => "gzip"
));
$result = curl_exec($ch);
if(strpos($result,'messages.INVALID_USERNAME')){
return 'true';
} else {
return 'false';
}
}
function tiktok($email){
$curl = curl_init();
curl_setopt_array($curl, array(
CURLOPT_URL => 'https://api2-t2.musical.ly/aweme/v1/passport/find-password-via-email/?version_code=7.6.0&language=ar&app_name=musical_ly&vid=43647C38-9344-40A3-AD8E-29F6C7B987E4&app_version=7.6.0&is_my_cn=0&channel=App%2520Store&mcc_mnc=&device_id=6999590732555060741&tz_offset=10800&account_region=&sys_region=SA&aid=1233&screen_width=1242&openudid=a0594f8115e0a1a51e1a31490aeef9afc2409ff4&os_api=18&ac=WIFI&os_version=12.5.4&app_language=ar&tz_name=Asia/Riyadh&device_platform=iphone&build_number=76001&iid=7021194671750481669&device_type=iPhone7,1&idfa=20DB6089-D1C6-49EF-8943-9C310C8F1B5D&mas=002ed4fcfe1207217efade4142d0b05e0c845e118f07206205d6a8&as=a11664d78a2e110bd08018&ts=16347494182',
CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS => 'email='.$email,
  CURLOPT_HTTPHEADER => array(
    'reqHostreq:  reqapi2-t2.musical.lyreq,',
    'reqAcceptreq:  req*/*req,',
    'reqContent-Typereq:  reqapplication/x-www-form-urlencodedreq,',
    'reqUser-Agentreq:  reqMusically/7.6.0 (iPhone; iOS 12.5.4; Scale/3.00)req,',
    'reqAccept-Languagereq:  reqar-SA;q=1req,',
    'reqContent-Lengthreq:  req25req,',
    'reqConnectionreq:  reqclosereq',
    'Content-Type: application/x-www-form-urlencoded',
    'Cookie: odin_tt=801cb69ce874fbd572fbebfcecd8ad00035280684f2afee746b526cc18466b9a6e2d05db44634b02861315c4a47060e3ce3f2979c113f55c61554986066384f8f2ab67e717d1184a64e8ad4448654a77'
  ),
));
$res = curl_exec($curl);
if(strpos($res, "Bind device by email failed") !== false){
return 'false';
} else {
return 'true';
}
}
/*
function GUID(){
    if (function_exists('com_create_guid') === true){
        return trim(com_create_guid(), '{}');
    }
    }

*/

class EzTGException extends Exception
{
}
function bot($method,$datas=[]){
    global $token;
$url = "https://api.telegram.org/bot".$token."/".$method;
$ch = curl_init();
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
$res = curl_exec($ch);
if(curl_error($ch)){
var_dump(curl_error($ch));
}else{
return json_decode($res);
}
}


class EzTG
{
    private $settings;
    private $offset;
    private $json_payload;
    public function __construct($settings, $base = false)
    {
        $this->settings = array_merge(array(
      'endpoint' => 'https://api.telegram.org',
      'token' => '1234:abcd',
      'callback' => function ($update, $EzTG) {
          echo 'no callback' . PHP_EOL;
      },
      'objects' => true,
      'allow_only_telegram' => true,
      'throw_telegram_errors' => true,
      'magic_json_payload' => false
    ), $settings);
        if ($base !== false) {
            return true;
        }
        if (!is_callable($this->settings['callback'])) {
            $this->error('Invalid callback.', true);
        }
        if (php_sapi_name() === 'cli') {
            $this->settings['magic_json_payload'] = false;
            $this->offset = -1;
            $this->get_updates();
        } else {
            if ($this->settings['allow_only_telegram'] === true and $this->is_telegram() === false) {
                http_response_code(403);
                echo '403 - You are not Telegram,.,.';
                return 'Not Telegram';
            }
            if ($this->settings['magic_json_payload'] === true) {
                ob_start();
                $this->json_payload = false;
                register_shutdown_function(array($this, 'send_json_payload'));
            }
            if ($this->settings['objects'] === true) {
                $this->processUpdate(json_decode(file_get_contents('php://input')));
            } else {
                $this->processUpdate(json_decode(file_get_contents('php://input'), true));
            }
        }
    }
    private function is_telegram()
    {
        if (isset($_SERVER['HTTP_CF_CONNECTING_IP'])) { //preferisco non usare x-forwarded-for xk si può spoof
            $ip = $_SERVER['HTTP_CF_CONNECTING_IP'];
        } else {
            $ip = $_SERVER['REMOTE_ADDR'];
        }
        if (($ip >= '149.154.160.0' && $ip <= '149.154.175.255') || ($ip >= '91.108.4.0' && $ip <= '91.108.7.255')) { //gram'''s ip : https://core.telegram.org/bots/webhooks
            return true;
        } else {
            return false;
        }
    }
    private function get_updates()
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->settings['endpoint'] . '/bot' . $this->settings['token'] . '/getUpdates');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        while (true) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, 'offset=' . $this->offset . '&timeout=10');
            if ($this->settings['objects'] === true) {
                $result = json_decode(curl_exec($ch));
                if (isset($result->ok) and $result->ok === false) {
                    $this->error($result->description, false);
                } elseif (isset($result->result)) {
                    foreach ($result->result as $update) {
                        if (isset($update->update_id)) {
                            $this->offset = $update->update_id + 1;
                        }
                        $this->processUpdate($update);
                    }
                }
            } else {
                $result = json_decode(curl_exec($ch), true);
                if (isset($result['ok']) and $result['ok'] === false) {
                    $this->error($result['description'], false);
                } elseif (isset($result['result'])) {
                    foreach ($result['result'] as $update) {
                        if (isset($update['update_id'])) {
                            $this->offset = $update['update_id'] + 1;
                        }
                        $this->processUpdate($update);
                    }
                }
            }
        }
    }
    public function processUpdate($update)
    {
        $this->settings['callback']($update, $this);
    }
    protected function error($e, $throw = 'default')
    {
        if ($throw === 'default') {
            $throw = $this->settings['throw_telegram_errors'];
        }
        if ($throw === true) {
            throw new EzTGException($e);
        } else {
            echo 'Telegram error: ' . $e . PHP_EOL;
            return array(
        'ok' => false,
        'description' => $e
      );
        }
    }
    public function newKeyboard($type = 'keyboard', $rkm = array('resize_keyboard' => true, 'keyboard' => array()))
    {
        return new EzTGKeyboard($type, $rkm);
    }
    public function __call($name, $arguments)
    {
        if (!isset($arguments[0])) {
            $arguments[0] = array();
        }
        if (!isset($arguments[1])) {
            $arguments[1] = true;
        }
        if ($this->settings['magic_json_payload'] === true and $arguments[1] === true) {
            if ($this->json_payload === false) {
                $arguments[0]['method'] = $name;
                $this->json_payload = $arguments[0];
                return 'json_payloaded'; //xd
            } elseif (is_array($this->json_payload)) {
                $old_payload = $this->json_payload;
                $arguments[0]['method'] = $name;
                $this->json_payload = $arguments[0];
                $name = $old_payload['method'];
                $arguments[0] = $old_payload;
                unset($arguments[0]['method']);
                unset($old_payload);
            }
        }
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->settings['endpoint'] . '/bot' . $this->settings['token'] . '/' . urlencode($name));
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($arguments[0]));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        if ($this->settings['objects'] === true) {
            $result = json_decode(curl_exec($ch));
        } else {
            $result = json_decode(curl_exec($ch), true);
        }
        curl_close($ch);
        if ($this->settings['objects'] === true) {
            if (isset($result->ok) and $result->ok === false) {
                return $this->error($result->description);
            }
            if (isset($result->result)) {
                return $result->result;
            }
        } else {
            if (isset($result['ok']) and $result['ok'] === false) {
                return $this->error($result['description']);
            }
            if (isset($result['result'])) {
                return $result['result'];
            }
        }
        return $this->error('Unknown error', false);
    }
    public function send_json_payload()
    {
        if (is_array($this->json_payload)) {
            ob_end_clean();
            echo json_encode($this->json_payload);
            header('Content-Type: application/json');
            ob_end_flush();
            return true;
        }
    }
}
class EzTGKeyboard
{
    public function __construct($type = 'keyboard', $rkm = array('resize_keyboard' => true, 'keyboard' => array()))
    {
        $this->line = 0;
        $this->type = $type;
        if ($type === 'inline') {
            $this->keyboard = array(
        'inline_keyboard' => array()
      );
        } else {
            $this->keyboard = $rkm;
        }
        return $this;
    }
    public function add($text, $callback_data = null, $type = 'auto')
    {
        if ($this->type === 'inline') {
            if ($callback_data === null) {
                $callback_data = trim($text);
            }
            if (!isset($this->keyboard['inline_keyboard'][$this->line])) {
                $this->keyboard['inline_keyboard'][$this->line] = array();
            }
            if ($type === 'auto') {
                if (filter_var($callback_data, FILTER_VALIDATE_URL)) {
                    $type = 'url';
                } else {
                    $type = 'callback_data';
                }
            }
            array_push($this->keyboard['inline_keyboard'][$this->line], array(
        'text' => $text,
        $type => $callback_data
      ));
        } else {
            if (!isset($this->keyboard['keyboard'][$this->line])) {
                $this->keyboard['keyboard'][$this->line] = array();
            }
            array_push($this->keyboard['keyboard'][$this->line], $text);
        }
        return $this;
    }
    public function newline()
    {
        $this->line++;
        return $this;
    }
    public function done()
    {
        if ($this->type === 'remove') {
            return '{"remove_keyboard": true}';
        } else {
            return json_encode($this->keyboard);
        }
    }
}